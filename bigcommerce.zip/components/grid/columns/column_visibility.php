<?php

class ColumnVisibility
{
    const PHONE = 1;
    const TABLET = 2;
    const DESKTOP = 3;
    const LARGE_DESKTOP = 4;
}

