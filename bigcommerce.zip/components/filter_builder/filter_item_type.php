<?php

class FilterItemType {
    const Group = 1;
    const Condition = 2;
}
