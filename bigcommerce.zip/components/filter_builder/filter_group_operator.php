<?php

class FilterGroupOperator {
    const LogicAnd = 1;
    const LogicOr = 2;
    const LogicNone = 3;
}
